import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import * as VueRouter from 'vue-router';
import Home from './pages/Home.vue'
import Languages from './pages/Languages.vue'
import Sheduler from './pages/Sheduler.vue'

const routes = [
    { path: '/', component: Home },
    { path: '/languages', component: Languages },
    { path: '/scheduler', component: Sheduler },
]

const router = VueRouter.createRouter({
    history: VueRouter.createWebHistory(),
    routes,
})


createApp(App)
    .use(router)
    .mount('#app')
