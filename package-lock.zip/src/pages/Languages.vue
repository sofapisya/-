<template>
<Card />
</template>

<script>
import Card from "../components/Card.vue";

export default {
  name: "Languages",
  components: {Card}
}
</script>

<style scoped>

</style>