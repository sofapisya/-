<template>
  <div style="display: flex; flex-direction: column">
<h2>
  Английский язык
</h2>
  <table>
    <thead>
    <tr>
      <th>Язык</th>
      <th>День</th>
      <th>Время</th>
    </tr>
    </thead>
    <tbody>
    <tr>
      <td>Английский для начинающих</td>
      <td>Понедельник</td>
      <td>18:00-19:30</td>
    </tr>
    <tr>
      <td>Английский для начинающих</td>
      <td>Понедельник</td>
      <td>18:00-19:30</td>
    </tr>
    <tr>
      <td>Английский для начинающих</td>
      <td>Понедельник</td>
      <td>18:00-19:30</td>
    </tr>
    </tbody>
  </table>
  </div>
</template>

<script>
export default {
  name: "Sheduler"
}
</script>

<style scoped>

</style>