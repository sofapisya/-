<template>
  <div style="display: flex;flex-direction: column;padding: 20px;max-width: 800px;max-height: 400px;background-color: #f6f6f6;border-radius: 10px;">
    <h2 style="font-weight: bold; text-align: left;margin-top: 0;margin-bottom: 0;">Английский</h2>
    <div style="display: flex;flex-direction: row;gap: 10px;">
      <h2 style="font-weight: bold">Преимущества изучения:    </h2>
      <h2 style="font-weight: normal"> международный язык что то там</h2>
    </div>
    <div style="display: flex;flex-direction: row;gap: 10px;">
      <h2 style="font-weight: bold;gap: 10px;">Цена за курс: </h2>
      <h2 style="">200$</h2>
    </div>
    <button style="background-color: #1a1a1a;border-radius: 10px;max-width: 150px;max-height: 50px;display: flex;justify-content: center;align-items: center;">
      <h2 style="color: white;text-align: center;margin-top: 0;margin-bottom: 0;">Записаться</h2>
    </button>
  </div>
</template>

<script>
export default {
  name: "Card",
  props: {
    title: "",

  }
}
</script>

<style scoped>

</style>